﻿using BusinessObjects;
using DataAccessLayer.BusinessObjects;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NguyenMinhQuangWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private AppDbContext _context;
        public MainWindow()
        {
            InitializeComponent();
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);

            IConfigurationRoot configuration = builder.Build();
            var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
            optionsBuilder.UseSqlServer(configuration.GetConnectionString("DefaultConnection"));

            _context = new AppDbContext(optionsBuilder.Options);
            LoadData();
        }

        private void LoadData()
        {
            // Load data from the database
            LoadCustomers();
            LoadRooms();
        }
        private void LoadCustomers()
        {
            var customers = _context.Customers.ToList();
            CustomerDataGrid.ItemsSource = customers;
        }
        private void LoadRooms()
        {
            var rooms = _context.RoomInformations.ToList();
            RoomDataGrid.ItemsSource = rooms;
        }

        private void CustomerDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CustomerDataGrid.SelectedItem is Customer selectedCustomer)
            {
                txtCustomerFullName.Text = selectedCustomer.CustomerFullName;
                txtCustomerTelephone.Text = selectedCustomer.Telephone;
                txtCustomerEmail.Text = selectedCustomer.EmailAddress;
                dpCustomerBirthday.SelectedDate = selectedCustomer.CustomerBirthday;
                cbCustomerStatus.SelectedIndex = selectedCustomer.CustomerStatus == 1 ? 0 : 1;
            }
        }

        private void btnCreateCustomer_Click(object sender, RoutedEventArgs e)
        {
            var newCustomer = new Customer
            {
                CustomerFullName = txtCustomerFullName.Text,
                Telephone = txtCustomerTelephone.Text,
                EmailAddress = txtCustomerEmail.Text,
                CustomerBirthday = dpCustomerBirthday.SelectedDate ?? DateTime.Now,
                CustomerStatus = (cbCustomerStatus.SelectedItem as ComboBoxItem)?.Tag.ToString() == "1" ? 1 : 2
            };

            _context.Customers.Add(newCustomer);
            _context.SaveChanges(); // Save changes to the database
            LoadCustomers(); // Refresh the DataGrid

            ClearCustomerInputs();
        }

        private void btnUpdateCustomer_Click(object sender, RoutedEventArgs e)
        {
            if (CustomerDataGrid.SelectedItem is Customer selectedCustomer)
            {
                selectedCustomer.CustomerFullName = txtCustomerFullName.Text;
                selectedCustomer.Telephone = txtCustomerTelephone.Text;
                selectedCustomer.EmailAddress = txtCustomerEmail.Text;
                selectedCustomer.CustomerBirthday = dpCustomerBirthday.SelectedDate ?? DateTime.Now;
                selectedCustomer.CustomerStatus = (cbCustomerStatus.SelectedItem as ComboBoxItem)?.Tag.ToString() == "1" ? 1 : 2;

                _context.Customers.Update(selectedCustomer);
                _context.SaveChanges(); // Save changes to the database
                LoadCustomers(); // Refresh the DataGrid

                ClearCustomerInputs();
            }
            else
            {
                MessageBox.Show("Please select a customer to update.");
            }
        }

        private void btnCreateRoom_Click(object sender, RoutedEventArgs e)
        {
            var newRoom = new RoomInformation
            {
                RoomNumber = txtRoomNumber.Text,
                RoomMaxCapacity = int.TryParse(txtRoomMaxCapacity.Text, out var capacity) ? capacity : 0,
                RoomStatus = (cbRoomStatus.SelectedItem as ComboBoxItem)?.Tag.ToString() == "1" ? 1 : 2,
                RoomPricePerDay = decimal.TryParse(txtRoomPrice.Text, out var price) ? price : 0
            };

            _context.RoomInformations.Add(newRoom);
            _context.SaveChanges(); // Save changes to the database
            LoadRooms(); // Refresh the DataGrid

            ClearRoomInputs();
        }

        private void RoomDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (RoomDataGrid.SelectedItem is RoomInformation selectedRoom)
            {
                txtRoomNumber.Text = selectedRoom.RoomNumber;
                txtRoomMaxCapacity.Text = selectedRoom.RoomMaxCapacity.ToString();
                txtRoomPrice.Text = selectedRoom.RoomPricePerDay.ToString("F2");
                cbRoomStatus.SelectedIndex = selectedRoom.RoomStatus == 1 ? 0 : 1;
            }
        }

        private void btnUpdateRoom_Click(object sender, RoutedEventArgs e)
        {
            if (RoomDataGrid.SelectedItem is RoomInformation selectedRoom)
            {
                selectedRoom.RoomNumber = txtRoomNumber.Text;
                selectedRoom.RoomMaxCapacity = int.TryParse(txtRoomMaxCapacity.Text, out var capacity) ? capacity : 0;
                selectedRoom.RoomStatus = (cbRoomStatus.SelectedItem as ComboBoxItem)?.Tag.ToString() == "1" ? 1 : 2;
                selectedRoom.RoomPricePerDay = decimal.TryParse(txtRoomPrice.Text, out var price) ? price : 0;

                _context.RoomInformations.Update(selectedRoom);
                _context.SaveChanges(); // Save changes to the database
                LoadRooms(); // Refresh the DataGrid

                ClearRoomInputs();
            }
            else
            {
                MessageBox.Show("Please select a room to update.");
            }
        }

        private void btnDeleteRoom_Click(object sender, RoutedEventArgs e)
        {
            if (RoomDataGrid.SelectedItem is RoomInformation selectedRoom)
            {
                _context.RoomInformations.Remove(selectedRoom);
                _context.SaveChanges(); // Save changes to the database
                LoadRooms(); // Refresh the DataGrid

                ClearRoomInputs();
            }
            else
            {
                MessageBox.Show("Please select a room to delete.");
            }
        }

        private void btnCancelRoom_Click(object sender, RoutedEventArgs e)
        {
            ClearRoomInputs();
        }

        private void btnCancelCustomer_Click(object sender, RoutedEventArgs e)
        {
            ClearCustomerInputs();
        }

        private void btnDeleteCustomer_Click(object sender, RoutedEventArgs e)
        {
            if (CustomerDataGrid.SelectedItem is Customer selectedCustomer)
            {
                _context.Customers.Remove(selectedCustomer);
                _context.SaveChanges(); // Save changes to the database
                LoadCustomers(); // Refresh the DataGrid

                ClearCustomerInputs();
            }
            else
            {
                MessageBox.Show("Please select a customer to delete.");
            }
        }

        
        private void ClearCustomerInputs()
        {
            txtCustomerFullName.Clear();
            txtCustomerTelephone.Clear();
            txtCustomerEmail.Clear();
            dpCustomerBirthday.SelectedDate = null;
            cbCustomerStatus.SelectedIndex = -1;
        }
        private void ClearRoomInputs()
        {
            txtRoomNumber.Clear();
            txtRoomMaxCapacity.Clear();
            txtRoomPrice.Clear();
            cbRoomStatus.SelectedIndex = -1;
        }
        private void txtCustomerFullName_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
          
        }

    }
}