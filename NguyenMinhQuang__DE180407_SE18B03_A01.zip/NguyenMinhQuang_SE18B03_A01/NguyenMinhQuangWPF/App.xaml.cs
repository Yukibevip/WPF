﻿using DataAccessLayer.BusinessObjects; // Import your DbContext
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Windows;

namespace NguyenMinhQuangWPF
{
    public partial class App : Application
    {
        private IServiceProvider _serviceProvider;

        public App()
        {
            // Set up the service provider for dependency injection
            var serviceCollection = new ServiceCollection();
            ConfigureServices(serviceCollection);
            _serviceProvider = serviceCollection.BuildServiceProvider();
        }

        private void ConfigureServices(ServiceCollection services)
        {
            // Configure AppDbContext with connection string to your database
            services.AddDbContext<AppDbContext>(options =>
               options.UseSqlServer("DefaultConnection"));
            // Replace with your actual connection string

            // Register MainWindow with dependency injection
            services.AddSingleton<MainWindow>();
        }

        // Override the OnStartup method to display the MainWindow
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Show the LoginWindow
            LoginWindow loginWindow = new LoginWindow();
            loginWindow.Show();

            // Handle login success
            loginWindow.LoginSuccess += (sender, args) =>
            {
                // Close the LoginWindow
                loginWindow.Close();

                // Show the MainWindow
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
            };
        }
    }
}
