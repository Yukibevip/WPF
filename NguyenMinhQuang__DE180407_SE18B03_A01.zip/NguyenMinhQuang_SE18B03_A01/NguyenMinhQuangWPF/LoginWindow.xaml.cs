﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Extensions.Configuration;
using System.IO;


namespace NguyenMinhQuangWPF
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        private IConfiguration _configuration;
        public event EventHandler LoginSuccess;
        public LoginWindow()
        {
            InitializeComponent();
            LoadConfiguration();
        }

        private void LoadConfiguration()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
            _configuration = builder.Build();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string email = txtUser.Text;
            string password = txtPass.Password;

            string storedEmail = _configuration["AdminCredentials:Email"];
            string storedPassword = _configuration["AdminCredentials:Password"];

            if (email == storedEmail && password == storedPassword)
            {
                MessageBox.Show("Login successful!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                LoginSuccess?.Invoke(this, EventArgs.Empty);
                // Create and show the main application window
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();

                // Close the login window
                this.Hide();  // Hide the login window instead of closing it immediately

                // Subscribe to the Closed event of the main window
                mainWindow.Closed += (s, args) => this.Close(); // Close the login window when the main window is closed
            }
            else
            {
                MessageBox.Show("Invalid email or password.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
