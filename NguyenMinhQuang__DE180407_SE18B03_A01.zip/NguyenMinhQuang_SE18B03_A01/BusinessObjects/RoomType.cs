﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjects
{
    public class RoomType
    {
        public int RoomTypeID { get; set; }               // Primary key
        public string? RoomTypeName { get; set; }          // Name of the room type (e.g., Standard, Deluxe)
        public string? TypeDescription { get; set; }       // Description of the room type
        public string? TypeNote { get; set; }
    }
}
