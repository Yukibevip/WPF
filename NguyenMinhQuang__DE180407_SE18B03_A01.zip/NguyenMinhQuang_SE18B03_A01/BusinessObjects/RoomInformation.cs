﻿using System.ComponentModel.DataAnnotations;

public class RoomInformation
{
    [Key] // This attribute marks the property as the primary key
    public int RoomID { get; set; }

    public string? RoomNumber { get; set; }
    public string? RoomDetailDescription { get; set; }
    public int RoomMaxCapacity { get; set; }
    public int RoomStatus { get; set; }
    public decimal RoomPricePerDay { get; set; }
    public int RoomTypeID { get; set; }
}
