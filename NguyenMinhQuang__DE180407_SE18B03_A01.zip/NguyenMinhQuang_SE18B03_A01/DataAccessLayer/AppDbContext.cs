﻿using BusinessObjects;
using System;
using System.IO;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace DataAccessLayer.BusinessObjects
{
    public class AppDbContext : DbContext
    {
        // Constructor for configuration
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        // Your DbSets here
        public DbSet<Customer> Customers { get; set; }
        public DbSet<RoomInformation> RoomInformations { get; set; }
        public DbSet<RoomType> RoomTypes { get; set; }


        // Configure the database connection
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                var builder = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);

                IConfigurationRoot configuration = builder.Build();
                optionsBuilder.UseSqlServer(configuration.GetConnectionString("DefaultConnection"));
            }
        }

        // You can override OnModelCreating to configure your entities if needed
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<RoomInformation>()
                .HasKey(r => r.RoomID); // Specify RoomID as the primary key

            // Configure RoomPricePerDay with a specific column type
            modelBuilder.Entity<RoomInformation>()
                .Property(r => r.RoomPricePerDay)
                .HasColumnType("decimal(18, 2)"); // Specify precision (18) and scale (2)

            // Example of seeding data
            modelBuilder.Entity<RoomInformation>().HasData(
                new RoomInformation
                {
                    RoomID = 1,
                    RoomNumber = "101",
                    RoomDetailDescription = "Deluxe Room with Sea View",
                    RoomMaxCapacity = 2,
                    RoomStatus = 1,
                    RoomPricePerDay = 100.00m, // This value should fit the specified precision and scale
                    RoomTypeID = 1
                }
            );

            // Add other configurations as needed
        }

    }
}
