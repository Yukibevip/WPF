﻿using BusinessObjects;
using DataAccessLayer.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class RoomRepository : IRoomRepository
    {
         
        private readonly AppDbContext context;

        public RoomRepository(AppDbContext context)
        {
            this.context = context;
        }

        public IEnumerable<RoomInformation> GetAll()
        {
            return context.RoomInformations.ToList();
        }

        public RoomInformation GetById(int id)
        {
            return context.RoomInformations.FirstOrDefault(r => r.RoomID == id);
        }

        public void Add(RoomInformation room)
        {
            context.RoomInformations.Add(room);
            context.SaveChanges();
        }

        public void Update(RoomInformation room)
        {
            context.RoomInformations.Update(room);
            context.SaveChanges();
        }

        public void Delete(int id)
        {
            var room = context.RoomInformations.FirstOrDefault(r => r.RoomID == id);
            if (room != null)
            {
                context.RoomInformations.Remove(room);
                context.SaveChanges();
            }
        }
    }
}
