﻿using BusinessObjects;
using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer
{
    public class RoomService : IRoomService
    {
        private readonly IRoomRepository _roomRepository;
        public RoomService(IRoomRepository roomRepository){
            _roomRepository = roomRepository;
            }
        public  IEnumerable<RoomInformation> GetAllRooms()
        {
            return _roomRepository.GetAll();
        }

        public RoomInformation GetRoomById(int id)
        {
            return _roomRepository.GetById(id);
        }

        public void AddRoom(RoomInformation room)
        {
            _roomRepository.Add(room);
        }

        public void UpdateRoom(RoomInformation room)
        {
            _roomRepository.Update(room);
        }

        public void DeleteRoom(int id)
        {
            _roomRepository.Delete(id);
        }
    }
}
